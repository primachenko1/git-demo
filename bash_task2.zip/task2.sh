#!/bin/bash

if [[ $# -ne 1 ]]; then
    echo "1 argument - Path to output.txt file - is needed" && exit 1
fi

ifile=$(cat "$1") || ( echo "can't read input file" && exit 1 )

while read line; do
    if [[ "${line:0:2}" == "[ " ]]; then # first line
        testName=$(echo "$line" | grep -o '\[.*\]') # retrieve name in brackets
        testName=${testName#[ } # remove prefix
        testName=${testName% ]} # remove suffix
        
        # identation is for final json
        IFS='' read -r -d '' json<<EOF
{
 "testName": "$testName",
 "tests": [
EOF
        
        continue
    fi
    
    if [[ "${line:0:2}" == "--" ]]; then continue; fi # separator line

    if [[ ${line:0:1} =~ [0-9] ]]; then # last line
        IFS=',' read -a fields <<< "$line" # read fields to an array
        success=$(echo "${fields[0]}" | awk -F' ' '{print $1}')
        failed=$(echo "${fields[1]}" | awk -F' ' '{print $1}')
        rating=$(echo "${fields[2]}" | awk -F' ' '{print $NF}')
        rating=${rating%$'%'} # trim % symbol at the end
        duration=$(echo "${fields[3]}" | awk -F' ' '{print $NF}')

        IFS='' read -r -d '' json3<<EOF
 ],
 "summary": {
  "success": $success,
  "failed": $failed,
  "rating": $rating,
  "duration": "$duration"
 }
}
EOF

        json="${json/%,$'\n'/$'\n'}" # cut comma before newline at the end
        json="$json$json3"

        continue
    fi

    if [[ "${line:0:2}" == "no" ]]; then # tests line 
        status="false"
        line=${line#not ok }
    fi
    if [[ "${line:0:2}" == "ok" ]]; then # tests line 
        status="true"
        line=${line#ok }
    fi
    
    # next section is for tests lines only
    #
    # get last field after space
    duration=$(echo "$line" | awk -F' ' '{print $NF}')
    line="${line%, "$duration"}" # remove suffix

    name=$(echo $line | sed 's/^\([0-9]\)*\s//') # remove test number and space

    IFS='' read -r -d '' json2<<EOF
   {
    "name": "$name",
    "status": $status,
    "duration": "$duration"
   },
EOF
    
    json="$json$json2"

done <<< "$ifile"

ofile="$(dirname "$1")/output.json"
echo "$json" > $ofile