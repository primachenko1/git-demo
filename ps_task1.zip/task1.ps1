param (
    # [Parameter] (Mandatory) argument will ask for input if corresponding parameter
    # is absent so to exit script instead in this case we assign terminating error message
    # as a default value
    # all validation of ip address parameters is done via [IPAddress] class
    # validation of netmask is manual
    [IPAddress]
    $ip_address_1=$(Write-Error "parameter ip_address_1 is mandatory" -ErrorAction Stop), 
    [IPAddress]
    $ip_address_2=$(Write-Error "parameter ip_address_2 is mandatory" -ErrorAction Stop), 
    $network_mask=$(Write-Error "parameter network_mask is mandatory" -ErrorAction Stop)
)

# no positional parameters
if ($args.Count -ne 0) {
    Write-Error "script accepts only following parameters: ip_address_1, ip_address_2, network_mask" -ErrorAction Stop
}

# netmask validation
if ($network_mask -match '^\d{1,2}$') { # netmask in xx format
    if (($network_mask -lt 1) -or ($network_mask -gt 32)) {
        Write-Error "network prefix must be in 1..32 range" -ErrorAction Stop
    }
    
    # convert to x.x.x.x format
    $network_mask_binary = ''
    for ($i = 1; $i -le $network_mask; $i++) {$network_mask_binary += '1'}
    $network_mask_binary = $network_mask_binary.PadRight(32, '0')
    
    $network_mask = ((0..3) | ForEach-Object {
        [Convert]::ToInt32($network_mask_binary.Substring(($_*8), 8), 2)
    }) -join '.'
}
elseif ($network_mask -match '^(\d{1,3}\.){3}\d{1,3}$') { # netmask in x.x.x.x format
    # convert to binary for validation
    $network_mask_binary = ($network_mask -split '\.' | 
        ForEach-Object {[Convert]::ToString($_, 2).PadLeft(8, '0')}) -join ''
    
    # no zeros before ones, also length is 32 exactly
    if (($network_mask_binary -match '01') -or ($network_mask_binary.Length -ne 32)) {
        Write-Error "invalid netmask" -ErrorAction Stop
    }
}
else {Write-Error "invalid netmask format" -ErrorAction Stop} # invalid or missing characters in netmask

$network_mask = [IPAddress] $network_mask # cast to [IPAddress]
# bitwise AND operator to obtain network part of ip address
if (($ip_address_1.Address -band $network_mask.Address) -eq ($ip_address_2.Address -band $network_mask.Address)) {
    Write-Host "yes"
}
else {
    Write-Host "no"
}