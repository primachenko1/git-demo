#!/bin/bash

if [[ $# -ne 1 ]]; then
    echo "1 argument - Path to accounts.csv file - is needed" && exit 1
fi

ifile=$(cat "$1") || ( echo "can't read input file" && exit 1 )

# taking into account only simple csv case like in example input file;
# no quotes in quotes, no matching quotes not at field boundaries,
# no multiline fields etc.
# for effective and performant import csv solution bash loadable builtins
# can be used, https://stackoverflow.com/a/69514496/1765658

while read line; do
    if [[ "${line:0:2}" == "id" ]]; then continue; fi # first line

    # we read fields with '"' IFS delimiter first to handle the case with commas
    # inside quotes in a field
    IFS='"' read -a fields <<< "$line" # read fields to an array

    # delimiter as a last character in the line doesn't produce empty field
    # after it in read built-in command so we add empty field in this case
    if [[ "${line:(-1):1}" == '"' ]]; then fields[${#fields[@]}]=''; fi

    # even number of fields means missing quote somewhere, we exit here
    if [[ $((${#fields[@]} % 2)) == 0 ]]; then
        echo "missing matching quote in '$line'"; exit 1
    fi

    # real fields (with ',' delimiter) may contain contents (including commas) 
    # in quotes but this will be valid only if opening quote is at the begining
    # of real field, so that previous character is comma (first field 'id' 
    # shouldn't have quotes)
    # in this case we mask commas inside quotes with backslashes to skip them 
    # in the next read of real fields (with ',' delimiter)
    #
    # content inside quotes is at even fields (with odd index) currently
    for ((i = 1; i < ${#fields[@]}; i+=2)); do
        pfield=${fields[$((i-1))]} # previous field
        field=${fields[$i]}
        if [[ "${pfield:(-1):1}" == ',' ]]; then
            fields[$i]=$(echo "$field" | sed 's/,/\\,/g')
        fi
    done

    # assemble fields back in the line
    line=${fields[0]}
    for ((i = 1; i < ${#fields[@]}; i++)); do line="$line\"${fields[$i]}"; done

    # now we read real fields with masked commas inside quotes;
    # backslashed commas won't be considered delimiters but will be
    # automatically unescaped during read
    IFS=',' read -a fields <<< "$line" # read fields to an array

    # handle the case of empty last field
    if [[ "${line:(-1):1}" == ',' ]]; then fields[${#fields[@]}]=''; fi

    name=${fields[2]}

    name2=${name,,} # all to lowercase first
    fname=$(echo "$name2" | cut -f1 -d' ') # first name
    lname=$(echo "$name2" | cut -f2 -d' ') # last name
    name2="${fname^} ${lname^}" # first letters to uppercase

    # during this loop emails are generated without location_id
    # because we do not have duplicates list yet
    email="${fname:0:1}$lname@abc.com"

    emails="$emails\n$email"
    lines="$lines\n${fields[0]},${fields[1]},$name2,${fields[3]},$email,${fields[5]}"
done <<< "$ifile"

# prepare the list of emails with duplicates
# grep excludes unique lines (with count 1)
# sed deletes white space with numbers before email
dups=$(echo -e "$emails" | sort | uniq -c | grep -v "\s1" | \
        sed 's/\s*\([0-9]\)*\s*//')

# adding location_id to emails with duplicates
while read email; do
    # for simplicity assume that e-mails do not appear in columns other than 'email'
    lines2=$(echo -e "$lines" | grep "$email")
    while read line; do
        location_id=$(echo $line | awk -F',' '{print $2}')
        #echo $line | sed "s/@/$location_id@/"
        line2=${line/@/"$location_id"@} # update email field
        lines=${lines/"$line"/"$line2"} # replace line with updated email
    done <<< "$lines2"
done <<< "$dups"

ofile="$(dirname "$1")/accounts_new.csv"
echo -e "id,location_id,name,title,email,department$lines" > $ofile
