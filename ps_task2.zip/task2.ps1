if ($args.Count -ne 1) {
    Write-Error "1 argument - Path to accounts.csv file - is needed" -ErrorAction Stop
}

$lines = Import-Csv $args[0]

# updating names and emails for a first run
foreach ($line in $lines) {
    $fname, $lname = -split $line.name.ToLower()
    $line.name = -join ($fname.Substring(0,1).ToUpper() + $fname.Substring(1),
                        $lname.Substring(0,1).ToUpper() + $lname.Substring(1))
    $line.email = $fname.Substring(0,1) + $lname + '@abc.com'
}

# list of duplicate emails
$dups = ($lines.email | Group-Object | Where-Object {$_.Count -ne 1}).Name

if ($dups.Count -gt 0) {
    # updating emails finally
    foreach ($line in $lines) {
        if ($dups.Contains($line.email)) {
            $line.email = $line.email.Replace('@',$line.location_id + '@')
        }
    }
}

$ofile = (Get-ChildItem $args[0]).DirectoryName + '/accounts_new.csv'
$lines | Export-Csv -UseQuotes AsNeeded $ofile
